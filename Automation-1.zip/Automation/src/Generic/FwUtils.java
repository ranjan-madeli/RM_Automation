package Generic;

public class FwUtils {

}
